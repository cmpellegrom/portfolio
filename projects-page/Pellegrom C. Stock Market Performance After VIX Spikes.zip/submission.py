
# MUST RUN AND IMPORT TICKER INTO THE "make_data_once.py" FILE
import sys
import pandas as pd
import matplotlib.pyplot as plt

def read_data(filename):
    df = pd.read_csv(filename, parse_dates=["Date"]) # Read CSV and parse Date
    df.columns = [c.strip().replace("*", "") for c in df.columns] # Normalize column names ("Adj Close*" from Yahoo)

    if "Close" not in df.columns and "Adj Close" in df.columns: # If Close is missing but Adj Close exists, use Adj Close (Yahoo library exclusive)
        df["Close"] = df["Adj Close"]

    df = df[["Date", "Close"]].copy() # Keep only Date and Close; force Close to numeric
    df["Close"] = pd.to_numeric(df["Close"], errors="coerce")

    df = df.dropna(subset=["Close"]).sort_values("Date") # Drop rows with missing/invalid Close, sort by date

    s = df.set_index("Date")["Close"] # Return Series: index=Date, values=Close (floats)
    return s



def percent_change(old, new): # Calculate percentage change from old to new
    if old == 0:
        return 0.0  # Return 0 to prevent division by 0
    return ((new - old) / old) * 100

def detect_vix_spikes(vix_close, threshold_percent):
    changes = vix_close.pct_change() * 100 # Computes day-to-day change and converts to a percentage
    mask = changes >= threshold_percent # Builds a True/False Series; True on dates where the daily % change meets or exceeds the threshold
    spike_dates = list(changes.index[mask]) # Makes a list of where the mask == True
    return spike_dates


def compute_returns(spike_dates, stock_data, days_after):
    returns = []
    for date in spike_dates: # Filter through stock Series to all dates >= spike date
        start_price = stock_data[stock_data.index >= date]
        if start_price.empty:
            continue # Skip if theres no stock data
        start_price = start_price.iloc[0] # Take the first trading day on or after that target date

        target_date = date + pd.Timedelta(days=days_after) # Compute the calendar date x days later
        end_price = stock_data[stock_data.index >= target_date] # Filter to the first trading day on/after that target date
        if end_price.empty:
            continue # Skip if end price can't be found
        end_price = end_price.iloc[0] # Take first available price as end price

        returns.append(percent_change(start_price, end_price)) # Compute the percent change and add it to the list
    return returns

def success_rate(returns):
    if not returns:
        return 0.0 # If the list is empty return 0 to avoid division by 0
    positive = [r for r in returns if r > 0] # Create a new list with only the positive returns
    return (len(positive) / len(returns)) * 100 # Convert positives to percentages

def make_plot(returns, outfile="returns_after_vix_spikes.png"):
    if not returns:
        return
    plt.figure()                          # Start a empty figure
    plt.bar(range(len(returns)), returns) # x = 0..n-1, y = return values
    plt.xlabel("Spike #")                 # x-axis label
    plt.ylabel("Return (%)")              # y-axis label
    plt.title("Returns N Days After VIX Spikes")  # Chart title
    plt.tight_layout()                    # Fix label/edge spacing
    plt.savefig(outfile)                  # Write the image file
    plt.close()                           # Free the figure from memory

def main():
    ticker = input("TICKER> ").strip() # Enter ticker like GOOGL or SPY etc.
    days_after = int(input("DAYS AFTER> ").strip()) # Enter the days after you want to see the return for
    threshold = float(input("THRESHOLD> ").strip())  # Enter threshold spike

    while threshold < 20: # Make threshold have to be greater than 20%
        print("Spike must be greater than or equal to 20%")
        threshold = float(input().strip())

    vix_data = read_data("vix_data.csv") # Read CSV files
    stock_data = read_data(f"{ticker}.csv")

    spikes = detect_vix_spikes(vix_data, threshold) # Find spike dates and compute returns
    if len(spikes) == 0:
        print(f"No VIX spikes >= {threshold:.2f}% found. Try a lower threshold or longer history.")
        return

    returns = compute_returns(spikes, stock_data, days_after)
    if len(returns) == 0:
        print("Could not compute any returns (no matching trading days).")
        return

    # --- Summaries ---
    sr = success_rate(returns)
    avg = sum(returns) / len(returns)
    mn = min(returns)
    mx = max(returns)

    # --- Output ---
    print(f"OUTPUT Ticker: {ticker}")
    print(f"OUTPUT Days after VIX spike: {days_after}")
    print(f"OUTPUT VIX spike threshold: {threshold:.2f}%")
    print(f"OUTPUT Number of spikes analyzed: {len(returns)}")
    print(f"OUTPUT Success rate (return > 0%): {sr:.2f}%")
    print(f"OUTPUT Average return: {avg:.2f}%")
    print(f"OUTPUT Min return: {mn:.2f}%")
    print(f"OUTPUT Max return: {mx:.2f}%")

    # --- Plot ---
    make_plot(returns)
    print("OUTPUT Saved plot: returns_after_vix_spikes.png")


# ---- Test Cases ----
def test_percent_change():
    assert abs(percent_change(100, 110) - 10.0) < 1e-9

def test_success_rate_basic():
    returns = [-5, 0, 2, 3]
    assert abs(success_rate(returns) - 50.0) < 1e-9

def test_detect_vix_spikes_simple():
    import pandas as pd
    idx = pd.to_datetime(["2024-01-01","2024-01-02","2024-01-03"])
    s = pd.Series([10.0, 12.0, 9.0], index=idx)
    spikes = detect_vix_spikes(s, 20.0)
    assert pd.Timestamp("2024-01-02") in spikes
    assert pd.Timestamp("2024-01-03") not in spikes

def run_tests():
    print("OUTPUT Running tests...")
    test_percent_change()
    test_success_rate_basic()
    test_detect_vix_spikes_simple()
    print("OUTPUT All tests passed")

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1].lower() == "test":
        run_tests()
    else:
        main()
